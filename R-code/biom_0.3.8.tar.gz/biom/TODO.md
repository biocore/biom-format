The biom package is under very active development. 

Planned feature improvements are publicly catalogued at the main biom development site on github; specifically on the ["Issues" page for biom-format](https://github.com/biom-format/biom-format/issues)

If the feature you are hoping for is not listed, you are welcome to add it as a feature request "issue" on this page. This request will be publicly available and listed on the page.


