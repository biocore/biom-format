# The biom package for R

This is an R package for interfacing with the [BIOM](http://biom-format.org/) file format.

 * Feature requests and bug reports for this package should go in the [official Issues list for biom-format](https://github.com/biom-format/biom-format/issues)

 * Release version of the biom package (currently beta) intended for [CRAN](http://cran.r-project.org/).

